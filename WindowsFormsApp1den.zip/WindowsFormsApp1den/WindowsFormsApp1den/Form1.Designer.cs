﻿namespace WindowsFormsApp1den
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.addBtn = new System.Windows.Forms.Button();
            this.saveBtn = new System.Windows.Forms.Button();
            this.calculateBtn = new System.Windows.Forms.Button();
            this.nameTb = new System.Windows.Forms.TextBox();
            this.courseTb = new System.Windows.Forms.TextBox();
            this.groupTb = new System.Windows.Forms.TextBox();
            this.result1Tb = new System.Windows.Forms.TextBox();
            this.result4Tb = new System.Windows.Forms.TextBox();
            this.result3Tb = new System.Windows.Forms.TextBox();
            this.result2Tb = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Course = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(16, 411);
            this.listBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(480, 116);
            this.listBox1.TabIndex = 0;
            // 
            // addBtn
            // 
            this.addBtn.Location = new System.Drawing.Point(60, 42);
            this.addBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.addBtn.Name = "addBtn";
            this.addBtn.Size = new System.Drawing.Size(100, 28);
            this.addBtn.TabIndex = 1;
            this.addBtn.Text = "add";
            this.addBtn.UseVisualStyleBackColor = true;
            this.addBtn.Click += new System.EventHandler(this.addBtn_Click);
            // 
            // saveBtn
            // 
            this.saveBtn.Location = new System.Drawing.Point(60, 101);
            this.saveBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.saveBtn.Name = "saveBtn";
            this.saveBtn.Size = new System.Drawing.Size(100, 28);
            this.saveBtn.TabIndex = 2;
            this.saveBtn.Text = "save";
            this.saveBtn.UseVisualStyleBackColor = true;
            this.saveBtn.Click += new System.EventHandler(this.saveBtn_Click);
            // 
            // calculateBtn
            // 
            this.calculateBtn.Location = new System.Drawing.Point(60, 161);
            this.calculateBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.calculateBtn.Name = "calculateBtn";
            this.calculateBtn.Size = new System.Drawing.Size(100, 28);
            this.calculateBtn.TabIndex = 3;
            this.calculateBtn.Text = "calculate";
            this.calculateBtn.UseVisualStyleBackColor = true;
            this.calculateBtn.Click += new System.EventHandler(this.calculateBtn_Click);
            // 
            // nameTb
            // 
            this.nameTb.Location = new System.Drawing.Point(343, 44);
            this.nameTb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.nameTb.Multiline = true;
            this.nameTb.Name = "nameTb";
            this.nameTb.Size = new System.Drawing.Size(237, 48);
            this.nameTb.TabIndex = 4;
            // 
            // courseTb
            // 
            this.courseTb.Location = new System.Drawing.Point(343, 132);
            this.courseTb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.courseTb.Multiline = true;
            this.courseTb.Name = "courseTb";
            this.courseTb.Size = new System.Drawing.Size(237, 48);
            this.courseTb.TabIndex = 5;
            // 
            // groupTb
            // 
            this.groupTb.Location = new System.Drawing.Point(343, 222);
            this.groupTb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupTb.Multiline = true;
            this.groupTb.Name = "groupTb";
            this.groupTb.Size = new System.Drawing.Size(237, 48);
            this.groupTb.TabIndex = 6;
            // 
            // result1Tb
            // 
            this.result1Tb.Location = new System.Drawing.Point(343, 322);
            this.result1Tb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.result1Tb.Multiline = true;
            this.result1Tb.Name = "result1Tb";
            this.result1Tb.Size = new System.Drawing.Size(93, 53);
            this.result1Tb.TabIndex = 7;
            // 
            // result4Tb
            // 
            this.result4Tb.Location = new System.Drawing.Point(709, 322);
            this.result4Tb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.result4Tb.Multiline = true;
            this.result4Tb.Name = "result4Tb";
            this.result4Tb.Size = new System.Drawing.Size(93, 53);
            this.result4Tb.TabIndex = 8;
            // 
            // result3Tb
            // 
            this.result3Tb.Location = new System.Drawing.Point(583, 322);
            this.result3Tb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.result3Tb.Multiline = true;
            this.result3Tb.Name = "result3Tb";
            this.result3Tb.Size = new System.Drawing.Size(93, 53);
            this.result3Tb.TabIndex = 9;
            // 
            // result2Tb
            // 
            this.result2Tb.Location = new System.Drawing.Point(461, 322);
            this.result2Tb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.result2Tb.Multiline = true;
            this.result2Tb.Name = "result2Tb";
            this.result2Tb.Size = new System.Drawing.Size(93, 53);
            this.result2Tb.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(343, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 16);
            this.label1.TabIndex = 11;
            this.label1.Text = "Name";
            // 
            // Course
            // 
            this.Course.AutoSize = true;
            this.Course.Location = new System.Drawing.Point(343, 112);
            this.Course.Name = "Course";
            this.Course.Size = new System.Drawing.Size(50, 16);
            this.Course.TabIndex = 12;
            this.Course.Text = "Course";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(340, 202);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 16);
            this.label2.TabIndex = 13;
            this.label2.Text = "Group";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(340, 302);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 16);
            this.label3.TabIndex = 14;
            this.label3.Text = "exam1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(458, 302);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 16);
            this.label4.TabIndex = 15;
            this.label4.Text = "exam2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(580, 302);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 16);
            this.label5.TabIndex = 16;
            this.label5.Text = "exam3";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(706, 302);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 16);
            this.label6.TabIndex = 17;
            this.label6.Text = "exam4";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Course);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.result2Tb);
            this.Controls.Add(this.result3Tb);
            this.Controls.Add(this.result4Tb);
            this.Controls.Add(this.result1Tb);
            this.Controls.Add(this.groupTb);
            this.Controls.Add(this.courseTb);
            this.Controls.Add(this.nameTb);
            this.Controls.Add(this.calculateBtn);
            this.Controls.Add(this.saveBtn);
            this.Controls.Add(this.addBtn);
            this.Controls.Add(this.listBox1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button addBtn;
        private System.Windows.Forms.Button saveBtn;
        private System.Windows.Forms.Button calculateBtn;
        private System.Windows.Forms.TextBox nameTb;
        private System.Windows.Forms.TextBox courseTb;
        private System.Windows.Forms.TextBox groupTb;
        private System.Windows.Forms.TextBox result1Tb;
        private System.Windows.Forms.TextBox result4Tb;
        private System.Windows.Forms.TextBox result3Tb;
        private System.Windows.Forms.TextBox result2Tb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Course;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}

